Version 1.3.0:  May 25, 2020
-------------------------------------------------------------------------------
    
+ Updated schema set to v1.3.
+ Added `info` slot to `Schema` object containing general schema information.
  
Version 1.2.0:  August 17, 2018
-------------------------------------------------------------------------------
    
+ Updated schema set to v1.2.
+ Changed defaults to `base="1"` for read and write functions.
+ Updated example TSV file with coordinate changes, addition of 
  `germline_alignment` data and simplification of `sequence_id` values.

Version 1.1.0:  May 1, 2018
-------------------------------------------------------------------------------
    
Initial release.
