library(testthat)
library(airr)

test_check("airr")
